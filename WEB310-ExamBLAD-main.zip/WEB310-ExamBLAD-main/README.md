Bjarte Landråk

Adrian Dietrichs
# BLAD Spillplattform

## Oversikt
BLAD Spillplattform tilbyr et samlingspunkt for underholdning og produktivitet gjennom interaktive spill og en notattjeneste, integrert med avanserte brukeradministrasjonsfunksjoner. Plattformen er designet for å tilby brukerne en sikker og engasjerende måte å spille spill, lagre notater og administrere personlige innstillinger.

## Teknologier
- **Flask**: Et lettvektig rammeverk som er ideelt for rask utvikling av webapplikasjoner.
- **Flask-SQLAlchemy**: Benyttes for databaseinteraksjoner gjennom en ORM tilnærming.
- **Flask-Login**: Gir håndtering av brukersesjoner, som støtter sikker autentisering og autorisering.
- **SQLite**: En enkel, robust database som støtter alle nødvendige applikasjonsdata uten behov for tungvint konfigurasjon.
- **HTML/CSS/JavaScript**: Standard webteknologier for å forme og dynamisere brukergrensesnittet.
- **AJAX**: Benyttes for å sende og motta data uten å måtte laste inn siden på nytt.
- **Jinja2**: Templatemotor brukt i Flask for å generere HTML-sider fra backend-data.
- **Werkzeug**: Underliggende bibliotek for WSGI-applikasjoner, brukt av Flask for diverse funksjoner som request parsing og sikkerhet.
- **Bootstrap**: For styling og responsivt design av brukergrensesnittet.

## Instruksjoner for testing
Du kan logge inn med følgende brukernavn og passord for testing:

**Administrator**:

Brukernavn: admin

Passord: admin-passord

**Vanlig bruker**:

Brukernavn: regular

Passord: regular-passord

## Funksjoner

### Autentisering og Akseskontroll
Plattformen sikrer at all brukeraktivitet skjer over sikre kanaler med klarerte identiteter.

- **Innlogging**: Sikkerhetsmekanismer validerer brukerens kredensialer mot lagrede hash-verdier i databasen for å forhindre uautorisert tilgang.
- **Registrering**: Hver ny bruker får et unikt brukernavn. Systemet forhindrer duplisering av brukernavn for å unngå identitetskonflikter og forvirring.
- **Brukerroller**: Ved registrering tildeler systemet standardbrukere med begrensede rettigheter, mens den første brukeren automatisk blir tildelt admin-rettigheter.
- **Oppdater Passord**: Brukere har mulighet til å oppdatere passordene sine gjennom en sikker mekanisme som også innebærer en kontroll for å unngå gjenbruk av tidligere passord.

#### Detaljerte Passordregler
For å sikre sterke brukerkontoer har systemet følgende passordkrav:
- Minst 4 tegn langt, maksimalt 150 tegn.
- Passordet kan ikke inneholde mellomrom.
- Passord må bekreftes eksakt ved registrering for å unngå skrivefeil.

### Flash Varslinger (Brukerfeedback)
Systemet bruker flash-meldinger for å gi tilbakemeldinger på brukerens handlinger:
- **Autentiseringsfeil**: Informerer om feil brukernavn eller passord.
- **Registreringsfeil**: Gir beskjed hvis brukernavnet allerede eksisterer eller om de nødvendige feltene ikke er fylt ut korrekt.
- **Passordendringer**: Bekrefter vellykket passordendring eller informerer om mangler ved det nye passordet.

### Spill og Notater
- **Spill**: Brukere kan velge mellom forskjellige spill, spore deres poeng og se toppscore lister.
- **Notater**: Tilbyr en notattjeneste hvor brukere kan opprette, lagre og slette personlige notater. En søkefunksjon tillater filtrering basert på notatinnhold.

### Administrasjon av brukere (Admin-funksjoner)
- **Oversikt**: Admin har tilgang til en detaljert liste over alle systemets brukere med søkefunksjonalitet.
- **Slette brukere**: Tillater admin å fjerne brukere, med restriksjoner mot sletting av andre admin-brukere for å sikre systemintegritet.
- **Lagret søk**: I brukeroversikten kan også administratorer søke etter brukere. Hvis en administrator lukker siden under et søk, lagres søkestrengen i søkefeltet til neste gang administratoren åpner siden igjen.



# Sprettballen
"Sprettballen" er et dynamisk og engasjerende nettleserspill som er en del av BLAD Spillplattformen. Spillet utfordrer spilleren til å bryte blokker ved å kontrollere en bevegelig flåte nederst på skjermen for å holde en ball i spill.

## Spilleregler og Dynamikk
### Grunnleggende Regler
- **Målet** med spillet er å bruke en flåte kontrollert av spilleren til å sprette en ball oppover og bryte så mange blokker som mulig uten å miste ballen ned kanten.
- **Hvordan Spille**:
  - Bruk venstre og høyre pil på tastaturet for å bevege flåten sideveis.
  - Målet er å hindre ballen fra å falle ned ved å sprette den opp mot blokkene.
  - Når alle blokkene er ødelagt, går spilleren videre til neste nivå med flere og vanskeligere blokker.

### Tekniske Detaljer
- **Blokker**: Arrangert i et rutenett, hvor hver blokk forsvinner ved treff fra ballen.
- **Poengsystem**: Spilleren får poeng for hver blokk som brytes.
- **Nivåer**: Antallet og plasseringen av blokker øker i hvert nytt nivå.
- **Game Over**: Hvis ballen faller ned forbi flåten, avsluttes spillet og poengsummen registreres.

## Teknologi
- **HTML/CSS** for struktur og stil.
- **JavaScript** for spillogikken og interaktiviteten, med spesiell bruk av `canvas` elementet for grafisk representasjon.

## JavaScript Logikk
- **Oppstart og Spillkontroller**:
  - `startGame()` funksjonen setter spillet i gang og gjør spillflaten aktiv.
  - `ruleButtonClicked()` og `closeButtonClicked()` funksjoner kontrollerer visning og skjuling av spillreglene.
  - Event listeners for `keydown` og `keyup` håndterer flåtebevegelser.

- **Spillmekanikker**:
  - `movePaddle()` og `moveBall()` administrerer bevegelsen til både paddle og ball.
  - `draw()`, `drawBall()`, `drawPaddle()`, og `drawBricks()` er tegnefunksjoner som oppdaterer canvasen basert på spillets tilstand.
  - `gameOver()` funksjonen avslutter spillet og resetter parametere for nytt spill.

- **Spilloppdatering**:
  - `update()` er en animasjonsløkke som kontinuerlig oppdaterer spilltilstanden, sjekker for kollisjoner, og tegner spillkomponentene på nytt.



# Snake Spill

## Oversikt
Snake er en moderne implementasjon av det klassiske slangespillet hvor målet er å styre en slange rundt på skjermen for å spise mat, uten å treffe veggene eller sin egen hale. Spillet øker i vanskelighetsgrad ettersom slangen vokser lenger ved hvert inntak av mat.

## Hvordan Spille
- **Start Spillet**: Klikk på "Start Spill" knappen for å initiere spillet.
- **Styring**: Bruk piltastene (venstre, høyre, opp, ned) for å endre retningen på slangen.
- **Mål**: Spis så mange matbiter som mulig for å øke poengsummen din. Hver gang du spiser en matbit, vokser slangen.
- **Game Over**: Spillet avsluttes når slangen treffer kanten av spillområdet eller seg selv.

## Tekniske Detaljer
- **Game Area**: Spillområdet er en firkantet arena hvor både slangen og maten genereres tilfeldig.
- **Snake Mechanics**:
  - Slangen flytter med en konstant hastighet.
  - Kroppsdeler følger hodet i bevegelsen og tar forrige posisjon av delen foran seg.
- **Mat**:
  - Når slangen spiser maten, genereres ny mat i en tilfeldig posisjon innenfor arenaen.
  - Poeng tildeles for hver matbit spist.
  
## Poengsystem
- Poengsummen øker med hver bit av mat slangen spiser.
- Spillet sporer høyeste poengsummer og viser disse i en toppliste på skjermen.

## Teknologi
- **HTML** for spillstrukturen.
- **CSS** for layout og design.
- **JavaScript** for spilllogikk og dynamikk.
- **Flask** for server-side håndtering.
- **AJAX** for å oppdatere highscore uten å laste om siden.



# Bildegåter

## Oversikt
Bildespillet er en nettbasert applikasjon designet for å engasjere brukerne i et morsomt og interaktivt gjettelek. Brukerne blir presentert med en serie bilder og må korrekt identifisere dem for å tjene poeng. Applikasjonen sporer brukerens poengsum og gir tilbakemelding på deres prestasjon.

## Teknologier
- **HTML/CSS/JavaScript**: Standard webteknologier for strukturering, styling og tilføying av interaktivitet til brukergrensesnittet.
- **Flask** for server-side håndtering.

## Beskrivelse
Bildespillapplikasjonen lar brukere gjette innholdet i bilder som vises på skjermen. Hver riktige gjetning tjener brukeren poeng, og applikasjonen holder styr på poengsummen deres. Spillet består av flere nivåer, hver med forskjellige bilder å gjette på. Brukergrensesnittet er utformet for å være intuitivt og engasjerende, med tydelige instruksjoner og tilbakemelding til brukeren.

### Spillmekanikk
- Brukerne skriver inn gjetningene sine i et tekstfelt og sender dem inn.
- Applikasjonen sammenligner brukerens gjetning med riktig svar og oppdaterer poengsummen deretter.
- Etter at en gjetning er sendt inn, vises det neste bildet, og prosessen gjentas til alle bildene er gjettet.
- Når alle bildene er gjettet, vises brukerens endelige poengsum.



# Mattespill

## Oversikt
Mattespillet er en interaktiv nettapplikasjon som utfordrer brukernes matteferdigheter ved å presentere dem med en rekke multiplikasjonsoppgaver. Brukerne må svare riktig på så mange oppgaver som mulig innen en gitt tidsramme for å oppnå høyest mulig poengsum.

## Teknologi
- **HTML/CSS/JavaScript**: Strukturere, style og legge til interaktivitet i brukergrensesnittet.
- **Flask** for server-side håndtering.


## Beskrivelse
Mattespillet presenterer brukerne med multiplikasjonsoppgaver og måler deres evne til å svare riktig innen en gitt tidsfrist. Spillet starter når brukeren klikker på "Start" -knappen, og de må svare på så mange oppgaver som mulig før tiden løper ut. Hver riktig besvarte oppgave øker brukerens nåværende poengsum, mens feil svar har ingen innvirkning på poengsummen. Spillet er designet for å være engasjerende og utfordrende, og oppfordrer brukerne til å forbedre sine matteferdigheter mens de konkurrerer om høyeste poengsum.

### Spillmekanikk
- **Start Spillet**: Brukere starter spillet ved å klikke på "Start" -knappen.
- **Tidsramme**: Spillet har en tidsramme på 10 sekunder. Tiden vises under spillet, og når tiden er ute, avsluttes spillet.
- **Oppgavegenerering**: Spillet genererer multiplikasjonsoppgaver med tilfeldige tall.
- **Poengsum**: Brukerens poengsum økes for hver riktig besvarte oppgave.
- **Lagring av Høyeste Poengsum**: Høyeste poengsum lagres lokalt på brukerens enhet ved hjelp av LocalStorage.

### Funksjoner
- **High Score Visning**: Viser brukerens høyeste poengsum, lagret fra tidligere spill.
- **Tidsfrist**: Markerer hvor mye tid som gjenstår for å fullføre spillet.
- **Oppgavegenerering**: Genererer multiplikasjonsoppgaver og håndterer brukerens svar.
- **Poengoppdatering**: Oppdaterer brukerens nåværende poengsum basert på riktige svar.
- **Knappstyring**: Aktiverer og deaktiverer svarknapper avhengig av spillstatus.



# Notatmodul

## Oversikt
Notatmodulen er en enkel, men kraftig funksjon designet for å la brukere opprette, søke og administrere sine personlige notater innen applikasjonen. Den tilbyr et intuitivt grensesnitt for å legge til nye notater, en temaveksler for visuell tilpasning, og funksjonaliteter for å søke og organisere notater dynamisk.

## Funksjoner

### Legge til Notater
- **Opprett Notater**: Brukere kan skrive og lagre notater ved å skrive inn i et tekstfelt og klikke på "Lagre Notat"-knappen.
- **Skjemahåndtering**: Skjemaet sender til `{{ url_for('views.add_note') }}`, som behandler tillegg av notat på server-siden.

### Administrere Notater
- **Vise Notater**: Notater vises som individuelle kort inne i et rutenett. Hvert notatkort viser innholdet og opprettelsesdatoen for notatet.
- **Slette Notater**: Hvert notatkorts har en sletteknapp som sender til `{{ url_for('views.delete_note', note_id=note.id) }}`, som tillater brukere å fjerne notater de ikke lenger trenger.

### Søk og Organisering
- **Dynamisk Søk**: Brukere kan skrive inn i et søkefelt for å filtrere viste notater basert på deres innhold.
- **Dra og Slipp**: Notater kan organiseres gjennom et dra-og-slipp-grensesnitt, som forbedrer brukerinteraksjon og organisasjon.

### Temaveksling
- **Tilpass Utseende**: En temavekslerknapp lar brukere bytte det visuelle temaet til notatvisningen, og tilbyr et lys- eller mørkemodus for lett lesing avhengig av brukerpreferanse eller omgivelsesbelysning.

### Temaveksling
- Bytter CSS-klasse på body-elementet for å veksle temaer.

### Søkefiltrering
- Filtrer notater som vises basert på tekstinnmatning fra brukeren, oppdateres i sanntid ettersom brukeren skriver.

### Dra og Slipp
- Lar brukere dra notater og omorganisere deres rekkefølge. Bruker HTML5 Dra og Slipp API for å muliggjøre flytting av notatkort innenfor beholderen.

## Teknologi
- **HTML**: for spillstrukturen.
- **CSS**: for layout og design.
- **JavaScript**: for spilllogikk og dynamikk.
- **Flask**: for server-side håndtering.
- **AJAX**: for å oppdatere highscore uten å laste om siden.


# Brukeroversikt

## Oversikt
Brukeroversikt er en viktig funksjon i systemet som tillater administratorer å søke, vise, og administrere brukere. Denne funksjonaliteten er designet for å gi enkel tilgang til brukerinformasjon og håndtere brukertilganger i en sikker og oversiktlig måte.

## Funksjoner

### Søke etter Brukernavn
- Brukere kan søkes opp ved hjelp av et søkefelt. Dette lar administratorer raskt filtrere gjennom listen for å finne spesifikke brukere basert på brukernavn.
- Søkefunksjonen støtter både dynamisk søk og filtrering basert på input fra brukeren.

### Visning av Brukerinformasjon
- Brukerinformasjonen vises i en tabellformat som inkluderer bruker-ID, brukernavn, og brukerens rolle i systemet.
- Tabellen tillater også handlinger som sletting av brukere, forbeholdt de som har en rolle definert som "regular".

### Administrere Brukere
- Administratorer har muligheten til å slette brukere. Dette er begrenset kun til brukere med "regular" roller for å forhindre misbruk av administrativ tilgang.
- Sletteknappen aktiviseres ved siden av hver bruker som oppfyller kravene for sletting.

## Teknologi
- **HTML og Flask templating** for å generere dynamiske web sider.
- **CSS** for styling.
- **JavaScript** for funksjonaliteter som lokal lagring av søk, og dynamiske web handlinger som søk og visning.

## Sikkerhetsfunksjoner
- Kun administratorer har tilgang til brukeroversikten.
- Slettefunksjonen sikrer at kritiske brukere ikke kan fjernes utilsiktet.

## Lokal Lagring
- Systemet bruker `localStorage` for å huske det sist innskrevne søket. Dette forbedrer brukeropplevelsen ved å gjenopprette tidligere tilstander av søket ved neste besøk.

## Scriptfunksjonaliteter
- **validateSearch()**: Validerer søkeinput for å forhindre tomme søk.
- **showAllUsers()**: En funksjon som gjenoppretter fullstendig brukerliste uten filter.
- **Event Listeners**: Scriptet lytter til DOMContentLoaded for å laste inn lagrede søkepreferanser og håndterer søkeinnsendinger dynamisk.




